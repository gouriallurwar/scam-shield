# ScamShield

An educational multi-page web development mini-project built with HTML, CSS, JavaScript and LocalStorage.

## Run in VS Code
1. Extract the ZIP file.
2. Open the extracted `ScamShield` folder in VS Code.
3. Open `index.html`.
4. Recommended: install the Live Server extension, right-click `index.html`, and choose **Open with Live Server**.

You can also open `index.html` directly in a browser.

## Pages
- `index.html` – home
- `scan.html` – message and URL pattern checker
- `quiz.html` – six-question interactive awareness quiz
- `learn.html` – scam awareness guides
- `dashboard.html` – local scan and quiz history
- `about.html` – project objective and limitations

## LocalStorage keys
- `ss_scans` – stores scan type, result label, number of indicators and date. It does not store submitted message text or URLs.
- `ss_quizzes` – stores quiz score and date.

## Important limitations
The scanner uses simple local pattern rules. It is not connected to a live threat-intelligence service and cannot determine with certainty whether a message or website is safe or fraudulent. HTTPS does not prove a website is legitimate. The project is an educational awareness demo, not a security product.

## Four-person team split
1. Member 1: Home page and shared navigation/footer (`index.html`, `common.js`).
2. Member 2: Scanner page and detection logic (`scan.html`, `scanner.js`).
3. Member 3: Learning centre and About page (`learn.html`, `about.html`).
4. Member 4: Quiz, dashboard and testing (`quiz.html`, `dashboard.html`, `quiz.js`, `dashboard.js`).

All members should use the same shared `css/style.css` and coordinate changes through GitHub.
